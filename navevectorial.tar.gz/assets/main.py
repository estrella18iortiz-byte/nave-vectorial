import asyncio
import pygame
import math
import time
import random

# ============================================================
# 1. CONFIGURACION INICIAL
# ============================================================
pygame.init()

ANCHO, ALTO = 800, 600
FPS = 60

pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Nave Vectorial y Proyectiles 2D - Destruye Meteoritos")
reloj = pygame.time.Clock()

# Colores
NEGRO    = (10, 10, 20)
BLANCO   = (255, 255, 255)
CIAN     = (0, 255, 255)
AMARILLO = (255, 220, 0)
ROJO     = (255, 60, 60)
GRIS     = (160, 160, 160)
NARANJA  = (255, 140, 0)

# ============================================================
# 2. MODELO LOCAL DE LA NAVE
# ============================================================
MODELO_NAVE = [
    (0, -25),
    (-15, 15),
    (15, 15),
]

nave_x, nave_y = 400, 300
nave_angulo = 0.0
VELOCIDAD_NAVE = 3.0
VELOCIDAD_GIRO = 0.06

# ============================================================
# 3. FUNCIONES DE TRANSFORMACION
# ============================================================
def rotar_punto(px, py, angulo):
    cos_a = math.cos(angulo)
    sin_a = math.sin(angulo)
    return px * cos_a - py * sin_a, px * sin_a + py * cos_a

def transformar_vertices(vertices, x, y, angulo):
    return [(rx + x, ry + y) for rx, ry in
            (rotar_punto(vx, vy, angulo) for vx, vy in vertices)]

def punta_nave(x, y, angulo):
    vx, vy = rotar_punto(0, -25, angulo)
    return x + vx, y + vy

# ============================================================
# 4. GESTION DE PROYECTILES
# ============================================================
proyectiles = []
VELOCIDAD_PROYECTIL = 8.0
VIDA_PROYECTIL = 120
COOLDOWN_DISPARO = 0.25
ultimo_disparo = 0.0
RADIO_PROYECTIL = 3

def disparar(x, y, angulo):
    dir_x = math.sin(angulo)
    dir_y = -math.cos(angulo)
    proyectiles.append({
        "x": x, "y": y,
        "vx": dir_x * VELOCIDAD_PROYECTIL,
        "vy": dir_y * VELOCIDAD_PROYECTIL,
        "vida": VIDA_PROYECTIL,
        "radio": RADIO_PROYECTIL,
    })

def actualizar_proyectiles():
    global proyectiles
    for p in proyectiles:
        p["x"] += p["vx"]
        p["y"] += p["vy"]
        p["vida"] -= 1
    proyectiles = [
        p for p in proyectiles
        if p["vida"] > 0 and 0 <= p["x"] <= ANCHO and 0 <= p["y"] <= ALTO
    ]

# ============================================================
# 5. GESTION DE METEORITOS
# ============================================================
meteoritos = []
puntos = 0
VIDA_METEORITO_BASE = 1
SPAWN_INTERVALO = 1.2
ultimo_spawn = 0.0

def crear_meteorito():
    lado = random.choice(["izq", "der", "arr", "aba"])
    if lado == "izq":
        x, y = -30, random.randint(0, ALTO)
        vx, vy = random.uniform(1.0, 2.5), random.uniform(-1.0, 1.0)
    elif lado == "der":
        x, y = ANCHO + 30, random.randint(0, ALTO)
        vx, vy = -random.uniform(1.0, 2.5), random.uniform(-1.0, 1.0)
    elif lado == "arr":
        x, y = random.randint(0, ANCHO), -30
        vx, vy = random.uniform(-1.0, 1.0), random.uniform(1.0, 2.5)
    else:
        x, y = random.randint(0, ANCHO), ALTO + 30
        vx, vy = random.uniform(-1.0, 1.0), -random.uniform(1.0, 2.5)

    radio = random.randint(15, 30)
    lados = random.randint(6, 9)
    forma = []
    for i in range(lados):
        ang = 2 * math.pi * i / lados
        r = radio * random.uniform(0.75, 1.15)
        forma.append((math.cos(ang) * r, math.sin(ang) * r))

    meteoritos.append({
        "x": x, "y": y, "vx": vx, "vy": vy,
        "radio": radio,
        "forma": forma,
        "vida": VIDA_METEORITO_BASE,
        "rot": random.uniform(0, 2 * math.pi),
        "rot_vel": random.uniform(-0.04, 0.04),
    })

def actualizar_meteoritos():
    global meteoritos, puntos
    for m in meteoritos:
        m["x"] += m["vx"]
        m["y"] += m["vy"]
        m["rot"] += m["rot_vel"]

    proyectiles_restantes = []
    for p in proyectiles:
        impacto = False
        for m in meteoritos:
            if m["vida"] <= 0:
                continue
            dx = p["x"] - m["x"]
            dy = p["y"] - m["y"]
            if dx * dx + dy * dy <= (m["radio"] + p["radio"]) ** 2:
                m["vida"] -= 1
                impacto = True
                if m["vida"] <= 0:
                    puntos += 10
                break
        if not impacto:
            proyectiles_restantes.append(p)
    proyectiles[:] = proyectiles_restantes

    meteoritos[:] = [
        m for m in meteoritos
        if m["vida"] > 0 and -100 <= m["x"] <= ANCHO + 100 and -100 <= m["y"] <= ALTO + 100
    ]

def dibujar_meteorito(m):
    puntos_mundo = []
    for fx, fy in m["forma"]:
        rx, ry = rotar_punto(fx, fy, m["rot"])
        puntos_mundo.append((m["x"] + rx, m["y"] + ry))
    pygame.draw.polygon(pantalla, GRIS, puntos_mundo, 2)
    pygame.draw.polygon(pantalla, (70, 70, 80), puntos_mundo)

# ============================================================
# 6. BUCLE PRINCIPAL ASINCRONO
# ============================================================
async def main():
    global nave_x, nave_y, nave_angulo, ultimo_disparo, ultimo_spawn, puntos, ejecutando

    ejecutando = True
    while ejecutando:
        dt = reloj.tick(FPS) / 1000.0
        tiempo_actual = time.time()

        # ---- Eventos ----
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                ejecutando = False
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_SPACE:
                    if tiempo_actual - ultimo_disparo >= COOLDOWN_DISPARO:
                        px, py = punta_nave(nave_x, nave_y, nave_angulo)
                        disparar(px, py, nave_angulo)
                        ultimo_disparo = tiempo_actual

        # ---- Teclas mantenidas ----
        teclas = pygame.key.get_pressed()
        if teclas[pygame.K_a] or teclas[pygame.K_LEFT]:
            nave_angulo -= VELOCIDAD_GIRO
        if teclas[pygame.K_d] or teclas[pygame.K_RIGHT]:
            nave_angulo += VELOCIDAD_GIRO
        if teclas[pygame.K_w] or teclas[pygame.K_UP]:
            nave_x += math.sin(nave_angulo) * VELOCIDAD_NAVE
            nave_y -= math.cos(nave_angulo) * VELOCIDAD_NAVE

        # ---- Screen wrapping ----
        if nave_x < 0: nave_x = ANCHO
        elif nave_x > ANCHO: nave_x = 0
        if nave_y < 0: nave_y = ALTO
        elif nave_y > ALTO: nave_y = 0

        # ---- Spawn de meteoritos ----
        if tiempo_actual - ultimo_spawn >= SPAWN_INTERVALO:
            crear_meteorito()
            ultimo_spawn = tiempo_actual

        # ---- Actualizaciones ----
        actualizar_proyectiles()
        actualizar_meteoritos()

        # ---- Dibujo ----
        pantalla.fill(NEGRO)

        for m in meteoritos:
            dibujar_meteorito(m)

        for p in proyectiles:
            pygame.draw.circle(pantalla, AMARILLO, (int(p["x"]), int(p["y"])), p["radio"])

        vertices = transformar_vertices(MODELO_NAVE, nave_x, nave_y, nave_angulo)
        pygame.draw.polygon(pantalla, CIAN, vertices, 2)
        pygame.draw.polygon(pantalla, (0, 80, 80), vertices)

        px, py = punta_nave(nave_x, nave_y, nave_angulo)
        pygame.draw.circle(pantalla, ROJO, (int(px), int(py)), 3)

        # HUD
        fuente = pygame.font.Font(None, 24)


        texto = fuente.render(
            f"W/Flecha arriba: avanzar  A/D/Flechas: girar  ESPACIO: disparar  |  "
            f"Puntos: {puntos}  Meteoritos: {len(meteoritos)}  Proyectiles: {len(proyectiles)}",
            True, BLANCO
        )
        pantalla.blit(texto, (10, 10))

        pygame.display.flip()
        
        # CRUCIAL: Ceder el control al navegador en cada frame
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())